<?php

return array(
    'db' => array(
        'host'=> 'localhost',
        'name'=> 'your_db_name',
        'user'=> 'your_db_user',
        'pass'=> 'your_db_user_password',
    ),
    'router' => array(
        '/' => 'home',
        'contact' => 'contact',
        'about' => 'about',
    ),
    'template' => array(
        'dir' => 'views',
        'them' => 'base'
    )
);

 