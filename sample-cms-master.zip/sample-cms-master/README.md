Sample CMS
==========

Рабочий пример можно посмотреть на сайте - http://samplecms-webdevlab.rhcloud.com/

Проект создан в целях обучения


