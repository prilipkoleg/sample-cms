<?php
class DB {

} 